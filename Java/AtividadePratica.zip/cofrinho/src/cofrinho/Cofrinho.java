package cofrinho;
import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> coinList;
	
	
	public Cofrinho() {
		this.coinList = new ArrayList<>();
	}
	
	public void addCoin(Moeda coin) {
		this.coinList.add(coin);
	}//Metodo para adicionar moeda na lista de moedas 
	
	public void showCoins() {
		if (this.coinList.isEmpty()) {
			System.out.println("cofre vazio!");
			return;
		}//O método isEmpty()  verifica se a lista  está vazia ou não. 
		
		for(var coin : this.coinList) {
			coin.info();
		}// loop de iteração sobre uma lista de moedas
	}
	
	public void removeCoin(int position) {
		this.coinList.remove(position);
	}//metodo para remover moeda da lista
	
	public ArrayList<Moeda> getListCoins() {
        return this.coinList;
    }// metodo get para pegar a lista privada de moedas
	
	public double convertAll(){
        var amount = 0;
        for(var coin : this.coinList){
            amount += coin.toConvert();
        }
        return amount;
    }// metodo pra converter tudo pra real, ele itera sobre cada moeda e aciona o metodo de converter para real
	
}
 