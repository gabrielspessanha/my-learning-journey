package cofrinho;

public class Dolar extends Moeda{
	public Dolar(double value) {
		this.setValue(value);
	}
	
	@Override // @override pra indicar que está sobrescrevendo método info da class Moeda
	public void info() {
		System.out.println(Dolar.class.getSimpleName()+": "+ this.getValue());
	}// metodo getSimpleName pega o nome da class
	public double toConvert() {
		return this.getValue() * 4.81;
	}
}
