package cofrinho;

public class Euro extends Moeda{
	public Euro(double value) {
		this.setValue(value);
	}
	
	@Override // @override pra indicar que está sobrescrevendo método info da class Moeda
	public void info() {
		System.out.println(Euro.class.getSimpleName()+ ": "+ getValue());
	}// metodo getSimpleName pega o nome da class
	
	public double toConvert() {
		return this.getValue() * 5.35;
	}
	
}
