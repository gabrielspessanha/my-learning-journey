package cofrinho;

public class Menu {
	//menu pra acessar o cofre que será usado pra tornar o código mais simples na class princiapl.
	public static void main(){
		 
       System.out.println("COFRINHO: ");
       System.out.println("1- Adicionar Moeda");
       System.out.println("2- Remover Moeda");
       System.out.println("3- Listar Moeda");
       System.out.println("4- Calcular total convertido para Real");
       System.out.println("0- Finalizar");
	}
	
	 public static void addCoin() {
    	
		//menu de escolher a moeda
	    System.out.println("Escolher moeda: ");
	    System.out.println("1- Real");
	    System.out.println("2- Dolar");
	    System.out.println("3- Euro");
	    System.out.println("0- Sair");
    }
	 
	public static void removeCoin(){
	    System.out.println("Posição que deseja remover: ");
	}
	
}
