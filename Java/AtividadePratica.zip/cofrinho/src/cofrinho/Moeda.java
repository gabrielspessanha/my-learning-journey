package cofrinho;
//uso do abstract pra transformar em classe base,não permitindo ser instanciada diretamente.
public abstract class Moeda {
	private double value;
	public abstract void info();
	public abstract double toConvert();
	
	public void setValue(double value) {
		this.value = value;
	}
	public double getValue() {
		return this.value;
	}
}
