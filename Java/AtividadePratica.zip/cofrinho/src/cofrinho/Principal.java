package cofrinho;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		var selected = new Scanner(System.in);
		var cofrinho = new Cofrinho();
		while (true){
			Menu.main();
			try {// try é usado para executar um bloco de código e capturar qualquer exceção que possa ser lançada durante a execução desse bloco
				switch(selected.nextInt()) {
					case 1 -> {
						Menu.addCoin();// executa o menu principal perguntando qual moeda deseja adicionar
						switch (selected.nextInt()) {
	                        case 1 -> {
	                        	System.out.println("Digite o valor: ");
	                            cofrinho.addCoin(new Real(selected.nextDouble()));
	                            System.out.println("Moeda adicionada! ");
	                        }
	                        case 2 ->{
	                        	System.out.println("Digite o valor");
                                cofrinho.addCoin(new Dolar(selected.nextDouble()));
                                System.out.println("Moeda adicionada! ");
	                        }
	                        case 3->{
	                        	System.out.println("Digite o valor");
	                        	cofrinho.addCoin(new Euro(selected.nextDouble()));
	                        	System.out.println("Moeda adicionada! ");
	                        }
	                        case 4->{
	                        	System.out.println("Saindo...");
	                        }
	                        default -> {
	                        	System.out.println("Valor Invalido! Escolha outra opção");
	                     
	
	                        }
                    }
						
					}
					case 2 -> {
						Menu.removeCoin();
						try {
                            cofrinho.removeCoin(selected.nextInt());
                        } catch (ArrayIndexOutOfBoundsException ex) {
                            System.out.println("Posicao inexistente!");
                            return;
                        }// Se o indice passado para método.removeCoin( ) não existir o bloco catch capitura essa exeção e executa o código dentro dele
					}
					case 3 -> {
						cofrinho.showCoins();
					}
					case 4 -> {
						System.out.printf("Valor total: R$%.2f \n",cofrinho.convertAll());
					}
					case 0 -> {
						System.out.println("Finalizando....");
						System.exit(0); // Encerra a execução do Programa
					}
					
				}
			} catch (NumberFormatException | InputMismatchException e) {
                System.out.println("Valor que está tentando digitar é invalido.");
               return;
            }//Está trantando possiveis erros na entrada de dados númericos de uma forma consistente a fornecer uma resposta adequada ao usuário.
			
			
		}
	}

}
