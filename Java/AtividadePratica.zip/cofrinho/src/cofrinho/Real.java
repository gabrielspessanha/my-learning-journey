package cofrinho;

public class Real extends Moeda{
	public Real(double value) {
		this.setValue(value);
	}
	
	@Override //@override pra indicar que está sobrescrevendo método info da class Moeda
	public void info() {
		System.out.println(Real.class.getSimpleName()+": "+ this.getValue());
	}// metodo getSimpleName pega o nome da class
	
	public double toConvert() {
		return this.getValue();
	}
}
